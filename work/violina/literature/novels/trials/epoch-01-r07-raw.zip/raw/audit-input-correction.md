# Round 07 审校输入纠正

- 根代理最初将文学守门文件误写为不存在的 `trials/prose-generation-guard.md`。
- 正确白名单路径是 `work/violina/literature/novels/prose-generation-guard.md`。
- 这是审校输入路径错误，不是 CandidateProse 问题。所有已使用错误路径的原始报告保留，不覆盖。
- 任何可能进入来源盲测的候选都必须由全新隔离审校者使用正确路径独立复审；只允许据此消除输入缺口，不得借机改稿或选择候选。
- U 的旧报告即使不依赖该守门文件，也已独立确认权威状态重置和开篇截断；为保持审计完整，若需引用最终硬结论，仍应以正确路径复审报告为准。
