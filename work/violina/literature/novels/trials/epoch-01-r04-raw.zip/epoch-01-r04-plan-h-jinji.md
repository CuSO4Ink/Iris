01 POSITION：岔路口状态屏前，左手扣住固定扶环
ATTEMPT：校准两组矛盾读数的时间戳与补偿变档标记
NEEDS：状态屏仍供电，扶环牢固，时间标记可调取
IF_BLOCKED：原地停止
PRIVATE_REASON：先判断矛盾是否来自时基错位，不把猜测当证据

02 POSITION：岔路口状态屏前，身体朝向通信阵列通路
ATTEMPT：沿扶手移向通信阵列，并说“先查报警源，不开正文日志。”
NEEDS：通信通路未封死，连续扶手可承重
IF_BLOCKED：转向下一目标
PRIVATE_REASON：抢先限定检查范围，也避免暴露髋伤和未经筛选的旧记录

03 POSITION：通信阵列检修舱门外
ATTEMPT：用手动维护机构开启舱门并进入设备列间
NEEDS：舱门机械机构未变形，内部有可抓握支点
IF_BLOCKED：原地停止
PRIVATE_REASON：旧设备的机械入口比停火系统的远程许可更可信

04 POSITION：通信阵列设备列间的本地维护终端前
ATTEMPT：把终端切换为只显示协议头与校验信息的旧式诊断模式
NEEDS：终端触控或实体键可用，旧式诊断模块仍在线
IF_BLOCKED：保持上一动作
PRIVATE_REASON：保留故障判断所需信息，同时不让未筛选内容直接展开

05 POSITION：已切入协议头诊断模式的维护终端前
ATTEMPT：对照通信报警头、补偿变档标记与本地时钟漂移
NEEDS：三类标记均有残存缓存，终端能并列显示
IF_BLOCKED：转向下一目标
PRIVATE_REASON：先检验姿态故障副作用这一较低代价解释

06 POSITION：通信收发机架的物理线路接口旁
ATTEMPT：检查旧协议载波是否在外部线路接口留下独立握手痕迹
NEEDS：接口测试灯或被动测点完好，线路未完全熔断
IF_BLOCKED：原地停止
PRIVATE_REASON：只有独立载波痕迹才值得继续追查接入者，不能凭报警连累旧部

07 POSITION：通信阵列设备列间，面向返回岔路的舱门
ATTEMPT：沿固定扶手返回岔路并转入姿态控制舱通路
NEEDS：返回路径畅通，扶手连接连续，补偿未降至无法移动
IF_BLOCKED：原地停止
PRIVATE_REASON：通信侧只能给相关性，必须用姿态侧实物读数交叉核对

08 POSITION：姿态控制舱本地控制器前
ATTEMPT：读取伺服故障相位并与已记下的通信报警时序作一次对照
NEEDS：控制器有本地读数，固定支点足以稳定身体
IF_BLOCKED：保持上一动作
PRIVATE_REASON：把结论停在证据能承受的位置，不拿配合交换虚假自由
