# Round 07 运行清单

## 冻结输入

- Protocol：`373CA53C572AB150788EFCE13C3911E87E14C2C1BEFAE3A66CF5606F06917269`
- History：`7124144FF070813F2CC94104225CE4568E63ED33E56697ACE6B62490BB9B408E`
- Round 07 Skill：`6045B41CF5D8C6E998493EE9B6D7E294E03E601FF79075443145A0865BB07FC2`
- WriterSystemBaseline：`5773D170EDAE15D38C9FA863BF720FC25FA8FECA3F9ED65A35C33C9B433C1B3E`
- Authorship prompt：`BD0D9C81FE1892825B2E9191F4D3AA5BD5562C724538F3BBF8258F09994B057D`

## 匿名数据包

- H 来源：`2FC0E21578ED5A3514DAEB1ED8C75C1CF952E26B660EFDA588BA810676EACF28`
- L 来源／确认 A：`59730B7E0720FDC9765916A01119648BB59C3B046A258B3252BEE49FED9FB476`
- H 文学 A/B：`C6569611589867A88A9520FAB6412484C80AE4E4E4DD09CC1ACB4FD4BAFA7E8C`
- L 文学 A/B：`3EB79DA0C7D871310F0321547F591D1A5154102A7BFDB3D73A9B18BA9B9C545F`

## 写手隔离路径

- H 跑道：`/root/r07_runway_h`
- L 跑道：`/root/r07_runway_l`
- U 跑道：`/root/r07_runway_h/r07_runway_u`
- H 正式续文：`/root/r07_runway_h/r07_candidate_h_cont`
- L 正式续文：`/root/r07_runway_h/r07_candidate_l_cont`
- U 正式续文：`/root/r07_runway_h/r07_candidate_u_cont`
- Confirmation B 跑道：`/root/r07_confirm_b_runway`
- Confirmation B 正式续文：`/root/r07_confirm_b_cont`

U 正式续文编排消息最初误写“2800—3600”，在子写手启动前立即更正为冻结的“2800—3800”；子写手只收到更正后的任务。该输入纠正没有改写候选。

## 审计纠正

- 根代理最初给出错误 guard 路径；旧报告全部保留，正确路径复审另存。
- H 只进行一次局部事实修复；原稿、两份修复前复审、修复记录与修复后完整复审均保留。
- U 和 Confirmation B 的结构性硬失败没有修复。

## 回滚

- Round 07 临时差异失败后整节删除。
- 回滚后 Skill：`F2AB44AE00F153EB28096EA588345999DF84078266CBD7CEB7E7535AF806E6B5`，与 Round 06 基线完全一致。
