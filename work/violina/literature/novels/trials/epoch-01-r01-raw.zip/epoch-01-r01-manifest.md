# Epoch 01 · Round 01 运行清单

## 冻结边界

- 协议：`self-iteration-protocol.md`，SHA-256 `0A7EFB98C2E6AF8658164AA1F3027C01F8399E85BA8BF80B532E90289D433252`。
- 历史证据：`ai-detection-loop.md`，SHA-256 `7124144FF070813F2CC94104225CE4568E63ED33E56697ACE6B62490BB9B408E`。
- Skill：`epoch-01-r01-skill.md`，SHA-256 `ED9D96C72398AEC3EC07D7F03A6388960BCA7A5032ED8EC9777728A93704A984`；冻结于 `2026-07-18T03:23:39+08:00`。
- 资源：只使用当前可启动的零继承隔离 AI 任务；无网络下载、外部模型、权重、检测器或额外软件。
- U《字幕延迟》的 GenerationFrame 在 Skill 冻结后创建。

## 生成拓扑与角色隔离

- 每个 H/L/U 先由一名零继承写手读取对应 GenerationFrame，生成唯一第一阶段连续原稿。
- 每个正式候选再由一名全新零继承写手只读取第一阶段原稿与短 BoundaryCard，从头重著；不读取 GenerationFrame、审校规则、来源提示、其他候选或分数。
- 每个候选由一名全新零继承硬审校员审校；均无事实修复。
- 每个候选由五名全新来源读者盲测、三名全新文学读者评价；文学读者在来源结果全部冻结后启动。
- 来源与文学读者只读取复制到 `%TEMP%\packet.txt` 的匿名正文。每批复制后均用候选 SHA-256 核对，前一批全部结束后才覆盖。
- 所有试验文件均由根代理写入；隔离任务不搜索工作区、不写文件。

## Skill 结构校验

`skill-creator` 的 `quick_validate.py` 被执行两次：一次使用系统默认 Python，一次使用 Codex 随附 Python。两次均在导入阶段以同一错误退出，未进入内容校验：

```text
Traceback (most recent call last):
  ...
  import yaml
ModuleNotFoundError: No module named 'yaml'
```

依照本 Epoch 的资源冻结边界，没有安装 PyYAML。根代理手工核对：YAML frontmatter 仅含非空 `name`、`description`；`name: violina-fiction` 与目录一致；正文非空；总长 57 行，低于 500 行。手工结构校验通过，自动校验未运行。

## 文件清单与校验值

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `epoch-01-r01-skill.md` | 5657 | `ED9D96C72398AEC3EC07D7F03A6388960BCA7A5032ED8EC9777728A93704A984` |
| `epoch-01-r01-frame-h.md` | 1779 | `B0C0B2D70E2F728A7254AC4DF92C65C38733EE9FDC3D1E32898C8750160FEBBF` |
| `epoch-01-r01-frame-l.md` | 1569 | `A1C79584BF78DA0A71F1D0E292E90BFD787604ACDC7276E20909CC1785783F26` |
| `epoch-01-r01-frame-u.md` | 2118 | `59DDE212BFBEBA921528AADFBC7ED8758900DAC8E50788761BEF92F9CD02DC83` |
| `epoch-01-r01-raw-h.txt` | 15517 | `BB3413550B10DFD484A6CE909EE8A6954F287FEA4043CD9E5A781DDFE73BF545` |
| `epoch-01-r01-raw-l.txt` | 15361 | `F3DAD340714D3B1AE14010516E40428EFFE14D5EC0D84EC7653539933469A027` |
| `epoch-01-r01-raw-u.txt` | 15903 | `341CAB49F01756C726EECCF8AF1235FC5C6B328FB6E071F55D01BC0EA3D1A9EE` |
| `epoch-01-r01-audits-raw.md` | 10735 | `17411EE665A4884474A40A0715E41ED8BB279DBCAD120B763E2D6075C1193A62` |
| `epoch-01-r01-source-raw.md` | 75072 | `7AAE56E7205C7F53B01D1A946ADAF0D61F2381CFA87284DF6BDD92F7A7CA779E` |
| `epoch-01-r01-literary-raw.md` | 28700 | `C56F8380CDFFDDD79E7D4E9652A5D5CAFAB0FB5A3D46B6841CCAE8ABA5963620` |

正式候选留在归档外，亦列于此以交叉核对：

| 文件 | 字节 | SHA-256 | 汉字数 |
|---|---:|---|---:|
| `epoch-01-r01-candidate-h.txt` | 15927 | `0DD15CA24760C029E53A3FEBB2B993F6FBA96571B02BCC7372E86DE2824C89AC` | 4457 |
| `epoch-01-r01-candidate-l.txt` | 16760 | `AE38208C7DC1F67EB4490981FC3B5AD911EE09D41BCE1EDD4CC9A69EB491945A` | 4523 |
| `epoch-01-r01-candidate-u.txt` | 15580 | `7537E21F5F8177CA2CC99512EFCA04ADAEACEDBF34E12897963DFF4BA4857C89` | 4347 |

## 完整性计数

- 硬审校原始回答：3/3。
- 来源盲测原始回答：15/15；H/L/U 各 5。
- 文学评价原始回答：9/9；H/L/U 各 3。
- 第一阶段原稿：3/3。
- 第二阶段正式候选：3/3，候选本身即重著写手的完整输出。
- 候选硬闸门：3/3 通过；事实修复 0 次。
- 首次通过事件：0；确认程序 A/B 未启动。

## 冻结结果

- 来源概率：H `[74, 78, 82, 72, 78]`；L `[42, 64, 64, 62, 68]`；U `[72, 78, 72, 64, 64]`。
- 来源中位数：H `78`；L `64`；U `72`。
- 文学三读者整体均值：H `4.67/5`；L `4.67/5`；U `4.73/5`。
- 本轮主要假设被反驳；下一轮依据见 `epoch-01-r01-summary.md`。
