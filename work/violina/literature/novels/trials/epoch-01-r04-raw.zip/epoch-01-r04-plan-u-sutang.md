01
POSITION / 后台仓库，两只老调光箱旁
ATTEMPT / 逐一打开箱盖，确认进水位置与湿透范围
NEEDS / 箱体可接近、锁扣可开、现场有足够照明
IF_BLOCKED / 原地停止
PRIVATE_REASON / 今晚必须先确认积水，拖到明天会腐蚀内部接点

02
POSITION / 后台仓库内尚未进水的地面
ATTEMPT / 把两只调光箱移出滴水范围，集中放到干处
NEEDS / 干处容得下两只箱，箱体与干处之间通路可走
IF_BLOCKED / 保持上一动作
PRIVATE_REASON / 先阻断继续受潮，才能争取拆晾和转运时间

03
POSITION / 仓库门口，面向后台搬运通道
ATTEMPT / “这两只今晚先上车，其他东西按剩下的地方装。”
NEEDS / 叶绮在可听范围，滴水与搬运声不至于盖住话音
IF_BLOCKED / 原地停止
PRIVATE_REASON / 设备虽不上巡演，却是县里日后恢复演出的稀缺家底

04
POSITION / 第一只调光箱与侧门之间的搬运线上
ATTEMPT / 把第一只调光箱搬到侧门货车旁
NEEDS / 通道未被布景或箱笼堵死，侧门保持开启
IF_BLOCKED / 保持上一动作
PRIVATE_REASON / 不先落实实物位置，口头留车位随时会被公开物资挤掉

05
POSITION / 第二只调光箱与侧门之间的搬运线上
ATTEMPT / 把第二只调光箱搬到第一只旁边
NEEDS / 第一只未堵住通路，货车仍停在侧门
IF_BLOCKED / 保持上一动作
PRIVATE_REASON / 两箱必须一起送去干处处理，留下一只同样会报废

06
POSITION / 侧门货车车厢口
ATTEMPT / 把两只调光箱并排安放进车厢最里侧
NEEDS / 车厢有容纳两箱的连续空位，箱体能平放站稳
IF_BLOCKED / 保持上一动作
PRIVATE_REASON / 设备优先装实，但不继续占用剩余车厢的支配权

07
POSITION / 后台档案堆旁的旧节目单盒前
ATTEMPT / 从盒中取出全部信件，收进贴身内袋
NEEDS / 节目单盒仍可辨认，信件未湿透，内袋容得下
IF_BLOCKED / 转向下一目标
PRIVATE_REASON / 礼堂即将封闭，继续混藏公开档案会把私密交给搬运偶然

08
POSITION / 侧门内侧，避开其他团员听闻的位置
ATTEMPT / “我不打算签短约，我想留县；你怎么选都别拿它证明我们。”
NEEDS / 叶绮在近处，周围无人能听清这句话
IF_BLOCKED / 原地停止
PRIVATE_REASON / 她拒绝用公开关系或去留一致换坦白，也不把留下当爱情凭证
