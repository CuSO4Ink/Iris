01
POSITION / 后台仓库通往侧门的干燥一侧
ATTEMPT / 把明早接收的档案箱集中到侧门内侧待装区
NEEDS / 档案箱可辨认，通道未被积水和杂物截断
IF_BLOCKED / 原地停止
PRIVATE_REASON / 档案今晚不上车就可能锁进临时库数月，必须先保住。

02
POSITION / 服装间靠门的空地
ATTEMPT / 挑出可直接用于演出的服装并封入待装箱
NEEDS / 戏服未被水浸，空箱和封箱绳可用
IF_BLOCKED / 转向下一目标
PRIVATE_REASON / 短约未签，先保住一套随时能演的家底，比搬全更要紧。

03
POSITION / 藏有合同样本的戏服箱旁
ATTEMPT / 从箱底取出个人合同样本，收进自己贴身口袋
NEEDS / 戏服箱尚未装车且箱底能够打开
IF_BLOCKED / 保持上一动作
PRIVATE_REASON / 样本只是个人选择的凭据，不是承诺，不能随公物一起失控。

04
POSITION / 侧门内的待装区
ATTEMPT / 只说：“档案和可演服装先上车，设备随后；签不签、留不留，由我自己定。”
NEEDS / 装车人员在听得见的范围内
IF_BLOCKED / 转向下一目标
PRIVATE_REASON / 装车次序要公开，职业去留也必须由我承担，不能被任何人代定。

05
POSITION / 侧门外的货车尾板
ATTEMPT / 先把全部档案箱装入车厢内侧
NEEDS / 货车到位，尾板稳固，档案箱已集中
IF_BLOCKED / 原地停止
PRIVATE_REASON / 明早只按公开清单接收，档案错过今晚就会失去掌控。

06
POSITION / 侧门与服装间之间
ATTEMPT / 把可演服装箱装在档案箱外侧并避开渗水处
NEEDS / 档案已装妥，服装箱封好，车厢仍有干燥位置
IF_BLOCKED / 保持上一动作
PRIVATE_REASON / 先让剧团保有开演能力，也避免合同样本随戏服箱被带走。

07
POSITION / 后台仓库设备区
ATTEMPT / 把车厢剩余空间能够容纳的灯具设备装车
NEEDS / 档案和可演服装已上车，尚有时间与安全载重
IF_BLOCKED / 转向下一目标
PRIVATE_REASON / 设备重要，但不能挤掉今晚以后最难追回的档案和演出服装。

08
POSITION / 舞台惯用台口
ATTEMPT / 独自完成一次无伴奏亮相身段，再站定片刻
NEEDS / 装车结束，舞台结构安全，货车开走前仍有数分钟
IF_BLOCKED / 原地停止
PRIVATE_REASON / 我要在离开前亲自确认，自己是否还愿意把职业留在这座舞台。
